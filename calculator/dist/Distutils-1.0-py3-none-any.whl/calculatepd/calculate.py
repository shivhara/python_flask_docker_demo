def calculatepdoutput(a,b):
    print("a+b is : ",a+b)