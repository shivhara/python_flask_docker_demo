from setuptools import setup

setup(name='Distutils',
      version='1.0',
      description='Python Distribution Utilities',
      author='akanksha shivhare',
      author_email='ankishashivhare@gmail.com',
      url='https://github.com/shivhara/python_flask_docker_demo',
      packages=['calculatepd'],
     )